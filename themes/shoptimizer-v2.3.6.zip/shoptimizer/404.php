<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package shoptimizer
 */

get_header(); ?>

<?php shoptimizer_404_template(); ?>

	<div id="primary" class="content-area">

		<main id="main" class="site-main">

			<div class="error-404 not-found">

				<div class="page-content">

					

					<?php //get_template_part( 'content', '404' ); ?>					

				</div><!-- .page-content -->
			</div><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer();
