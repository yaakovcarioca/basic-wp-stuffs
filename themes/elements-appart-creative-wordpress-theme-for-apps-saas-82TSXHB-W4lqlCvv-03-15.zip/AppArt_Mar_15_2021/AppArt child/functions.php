<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;


/**
 * Setup My Child Theme's textdomain.
 *
 * Declare textdomain for this child theme.
 * Translations can be filed in the /languages/ directory.
 */
function appart_child_theme_setup() {
    load_child_theme_textdomain( 'appart-child', get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'appart_child_theme_setup' );


// BEGIN ENQUEUE PARENT ACTION
if ( !function_exists( 'appart_child_thm_parent_css' ) ):
    function appart_child_thm_parent_css() {
        wp_enqueue_style(
            'appart-child-parent-root',
            trailingslashit( get_template_directory_uri() ) . 'style.css'
        );
    }
endif;
add_action( 'wp_enqueue_scripts', 'appart_child_thm_parent_css', 10 );

// END ENQUEUE PARENT ACTION
