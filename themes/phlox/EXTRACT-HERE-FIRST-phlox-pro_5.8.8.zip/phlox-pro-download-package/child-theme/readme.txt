Child theme is something about developers. if you are a developer and need to modify the theme core files, child theme is something handy for you. otherwise, you don’t need to use it.
more info: http://codex.wordpress.org/Child_Themes

