Electro - WooCommerce Wordpress Theme

The theme's documentation and the customer support are provided online. Here are a few useful links on getting started with the theme.

1. Theme Documentation - https://docs.madrasthemes.com/electro/
2. Support - https://themeforest.net/item/electro-electronics-store-woocommerce-theme/15720624/support/
3. Getting Started with WooCommerce - https://docs.woothemes.com/documentation/plugins/woocommerce/getting-started/
4. Getting Started with Wordpress - https://codex.wordpress.org/Getting_Started_with_WordPress
5. Step-by-step Installation Instruction - https://www.youtube.com/watch?v=YSm64d3G8jo&list=PLYq0ehQTXpCRuKysHN1BcPgRmyja93h_F