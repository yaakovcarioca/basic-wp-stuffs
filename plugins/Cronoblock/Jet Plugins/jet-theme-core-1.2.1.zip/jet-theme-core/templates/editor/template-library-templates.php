<?php
/**
 * Templates list view
 */
?>
<div id="jet-template-library-templates-container"></div>