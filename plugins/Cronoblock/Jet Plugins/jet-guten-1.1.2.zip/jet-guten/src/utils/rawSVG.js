export default function getRawSvgByID( imageID, callback ) {
	$.get(
		ajaxurl, {
			action: 'jet_guten_get_raw_svg',
			image_id: imageID
		},
		( response ) => {
			callback( response );
		}
	);
}
