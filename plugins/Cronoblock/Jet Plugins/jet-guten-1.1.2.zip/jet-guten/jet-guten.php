<?php
/**
 * Plugin Name: JetGuten for Gutenberg
 * Plugin URI: https://jetguten.zemez.io/
 * Description: Addon for Gutenberg made for adding more content to the pages using the set of specific blocks.
 * Version:     1.1.2
 * Author:      Zemez
 * Author URI:  https://zemez.io/wordpress/
 * Text Domain: jet-guten
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

define( 'JET_GUTEN_FILE', __FILE__ );
define( 'JET_GUTEN_PATH', trailingslashit( plugin_dir_path( JET_GUTEN_FILE ) ) );
define( 'JET_GUTEN_URL', plugins_url( '/', JET_GUTEN_FILE ) );
define( 'JET_GUTEN_VERSION', '1.1.2' );

require_once JET_GUTEN_PATH . 'includes/plugin.php';

/**
 * Initialize plugin
 *
 * @return void
 */

add_action( 'init', array( 'Jet_Guten_Plugin', 'get_instance' ) );
