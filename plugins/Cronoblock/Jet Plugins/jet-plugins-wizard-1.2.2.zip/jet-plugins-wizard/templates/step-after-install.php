<?php
/**
 * Install complete page
 */
?>
<h2><?php esc_html_e( 'Congratulations', 'jet-plugins-wizard' ); ?></h2>
<?php esc_html_e( 'Install complete', 'jet-plugins-wizard' ); ?>