<?php
/**
 * Wizard page header template
 */
?>
<div class="wrap">
	<div class="jet-plugins-wizard">
