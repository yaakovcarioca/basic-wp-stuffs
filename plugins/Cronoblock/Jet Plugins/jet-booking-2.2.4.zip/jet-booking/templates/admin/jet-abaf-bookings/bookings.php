<div class="wrap">
	<jet-abaf-bookings-list v-if="isSet"></jet-abaf-bookings-list>
	<div class="cx-vui-panel" v-else>
		<jet-abaf-go-to-setup></jet-abaf-go-to-setup>
	</div>
</div>