<?php
/**
 * Wishlist loop item remove button template
 */

echo jet_cw_functions()->get_wishlist_remove_button( $_product, $widget_settings );